#Develop the scripts for creating a database and its tables that can accommodate the data coming from the application you designed in the SD part. 

#Values 

use Career_Quiz_Database;

insert Quiz values
('1001','Coderstrust Academy Career Quiz');

insert Questions values
('2001','Grathical Design','1001'),
('2002','Grathical Design','1001'),
('2003','Grathical Design','1001'),
('2004','Grathical Design','1001'),
('2005','Programming','1001'),
('2006','Programming','1001'),
('2007','Programming','1001'),
('2008','Programming','1001'),
('2009','Social Media','1001'),
('2010','Social Media','1001'),
('2011','Social Media','1001'),
('2012','Social Media','1001');

insert Question_type values
('2001','Do you appreciate design in relation to products?'),
('2002','Do you have a favourite artist when it comes to visual art?'),
('2003','Do you enjoy making visual presentations for school or business?'),
('2004','Have you tried editing video on your mobile device or PC?'),
('2005','Do you like to take online intelligence tests?'),
('2006','Do you find numbers and logic is preferred over philosophical questions?'),
('2007','Are you interested in coding and learning to either understand or code yourself?'),
('2008','Have you tried building a website with a CMS like wordpress or Wix?'),
('2009','Are you very active on Social Media?'),
('2010','Do you care about who likes and comments on your posts?'),
('2011','Do you find that Social Media influences your buying decisions?'),
('2012','Do you believe that Social Media is more effective than traditional marketing?');

insert Visitor values
('3001','Eva','Mittag','evakea@gmail.com','Denmark'),
('3002','Nice','Matwara','nimakea@gmail.com','Sweden'),
('3003','Zainab','Afzal','zaafkea@gmail.com','Norway'),
('3004','Jacob','Christensen','jacobkea@gmail.com','Bangladesh');

insert Visitor_Answers values
('3001','2001','0','4'),
('3001','2002','0','1'),
('3001','2003','5','3'),
('3001','2004','5','1'),
('3001','2005','5','1'),
('3001','2006','0','1'),
('3001','2007','5','1'),
('3001','2008','0','4'),
('3001','2009','5','1'),
('3001','2010','5','2'),
('3001','2011','5','2'),
('3001','2012','0','7'),
('3002','2001','5','5'),
('3002','2002','0','5'),
('3002','2003','5','3'),
('3002','2004','5','7'),
('3002','2005','5','1'),
('3002','2006','0','2'),
('3002','2007','0','6'),
('3002','2008','5','3'),
('3002','2009','0','8'),
('3002','2010','5','7'),
('3002','2011','0','5'),
('3002','2012','5','8'),
('3003','2001','5','6'),
('3003','2002','5','5'),
('3003','2003','5','3'),
('3003','2004','5','7'),
('3003','2005','5','1'),
('3003','2006','5','8'),
('3003','2007','5','2'),
('3003','2008','0','3'),
('3003','2009','0','4'),
('3003','2010','5','4'),
('3003','2011','0','1'),
('3003','2012','0','8'),
('3004','2001','0','6'),
('3004','2002','5','8'),
('3004','2003','0','3'),
('3004','2004','5','8'),
('3004','2005','0','1'),
('3004','2006','5','9'),
('3004','2007','5','2'),
('3004','2008','5','3'),
('3004','2009','5','5'),
('3004','2010','5','4'),
('3004','2011','5','1'),
('3004','2012','0','1');
