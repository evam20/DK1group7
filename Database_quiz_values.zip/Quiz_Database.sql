#Develop the scripts for creating a database and its tables that can accommodate the data coming from the application you designed in the SD part. 

#Database 

create database Career_Quiz_Database;
use Career_Quiz_Database;

DROP TABLE IF EXISTS Quiz;
DROP TABLE IF EXISTS Questions;
DROP TABLE IF EXISTS Question_type;
DROP TABLE IF EXISTS Visitor;
DROP TABLE IF EXISTS Visitor_Answers;

create table Quiz (
	Quiz_ID				int NOT NULL,
    Quiz_details	 	varchar(100),
    
    PRIMARY KEY (Quiz_ID)
);
    
create table Questions (
	Question_ID 		int(5),
    Question_Category	varchar(50),
    Quiz_ID				int(5),
   
    PRIMARY KEY (Question_ID),
    FOREIGN KEY (Quiz_ID) REFERENCES Quiz(Quiz_ID)
);

create table Question_type (
	Question_ID		int(20),
	Question_name 	varchar(300),
    
    PRIMARY KEY (Question_name),
    FOREIGN KEY (Question_ID) REFERENCES Questions(Question_ID)
);

create table Visitor (
	Visitor_ID				int(100),
	Visitor_firstname   	varchar(100),
    Visitor_lastname		varchar(100),
	Visitor_email			varchar(100),
	Visitor_country			varchar(100),
	
	PRIMARY KEY (Visitor_ID)
);

create table Visitor_Answers (
	Visitor_ID 			int,
    Question_ID			int,
    Answers				int,
    Time_pr_Question	int,
    Answers_ID			int,
    
    PRIMARY KEY (Answers_ID),
	FOREIGN KEY (Visitor_ID) REFERENCES Visitor(Visitor_ID),
	FOREIGN KEY (Question_ID) REFERENCES Question_type(Question_ID)
    );
